#ASN para escanear  a rede
ASN="ASN"
#remove arquivos necessários
rm -rf /var/www/html/nmap/meu_asn.txt
#cria novos arquivos
echo $ASN >> /var/www/html/nmap/meu_asn.txt
echo $ASN2 >> /var/www/html/nmap/meu_asn.txt
echo $ASN3 >> /var/www/html/nmap/meu_asn.txt
echo $ASN4 >> /var/www/html/nmap/meu_asn.txt
echo $ASN5 >> /var/www/html/nmap/meu_asn.txt
rm -rf /var/www/html/nmap/portasespecificas/nmap161.txt
mkdir  /var/www/html/nmap/portasespecificas/historico
DATA=$(date +"%d-%m-%Y-%T")
DATA2=$(date +"%d/%m/%Y as %T")
CARREGAMENTO="Realizando a procura... espere"
rm -rf /var/www/html/nmap/portasespecificas/data.txt
echo $DATA2 >> /var/www/html/nmap/portasespecificas/data.txt
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap161.txt
nmap --open -p 161 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap161.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap161.txt

cp /var/www/html/nmap/portasespecificas/nmap161.txt /var/www/html/nmap/portasespecificas/historico/nmap161_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap21.txt

echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap21.txt

nmap --open -p 21 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap21.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap21.txt

cp /var/www/html/nmap/portasespecificas/nmap21.txt /var/www/html/nmap/portasespecificas/historico/nmap21_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap22.txt
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap22.txt
nmap --open -p 22 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap22.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap22.txt

cp /var/www/html/nmap/portasespecificas/nmap22.txt /var/www/html/nmap/portasespecificas/historico/nmap22_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap80.txt

echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap80.txt
nmap --open -p 80 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap80.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap80.txt

cp /var/www/html/nmap/portasespecificas/nmap80.txt /var/www/html/nmap/portasespecificas/historico/nmap80_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap53.txt

echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap53.txt
nmap --open -p 53 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap53.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap53.txt

cp /var/www/html/nmap/portasespecificas/nmap53.txt /var/www/html/nmap/portasespecificas/historico/nmap53_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap123.txt
CARREGAMENTO6="Realizando procura de portas 123... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap123.txt
nmap --open -p 123 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap123.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap123.txt

cp /var/www/html/nmap/portasespecificas/nmap123.txt /var/www/html/nmap/portasespecificas/historico/nmap123_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap111.txt
CARREGAMENTO7="Realizando procura de portas 111... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap111.txt
nmap --open -p 111 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap111.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap111.txt

cp /var/www/html/nmap/portasespecificas/nmap111.txt /var/www/html/nmap/portasespecificas/historico/nmap111_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap135.txt
CARREGAMENTO8="Realizando procura de portas 135... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap135.txt
nmap --open -p 135 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap135.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap135.txt

cp /var/www/html/nmap/portasespecificas/nmap135.txt /var/www/html/nmap/portasespecificas/historico/nmap135_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap3389.txt
CARREGAMENTO9="Realizando procura de portas 3389... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap3389.txt
nmap --open -p 3389 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap3389.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap3389.txt

cp /var/www/html/nmap/portasespecificas/nmap3389.txt /var/www/html/nmap/portasespecificas/historico/nmap3389_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap5353.txt
CARREGAMENTO10="Realizando procura de portas 5353... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap5353.txt
nmap --open -p 5353 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap5353.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap5353.txt

cp /var/www/html/nmap/portasespecificas/nmap5353.txt /var/www/html/nmap/portasespecificas/historico/nmap5353_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap1900.txt
CARREGAMENTO11="Realizando procura de portas 1900... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap1900.txt
nmap --open -p 1900 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap1900.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap1900.txt

cp /var/www/html/nmap/portasespecificas/nmap1900.txt /var/www/html/nmap/portasespecificas/historico/nmap1900_$DATA.txt

rm -rf /var/www/html/nmap/portasespecificas/nmap443.txt
CARREGAMENTO12="Realizando procura de portas 443... espere"
echo $CARREGAMENTO >> /var/www/html/nmap/portasespecificas/nmap443.txt
nmap --open -p 443 $ASN -oG - | grep "/open" | awk '{ print $2 }' >> /var/www/html/nmap/portasespecificas/nmap443.txt
sed -i '/Realizando/d' /var/www/html/nmap/portasespecificas/nmap443.txt

cp /var/www/html/nmap/portasespecificas/nmap443.txt /var/www/html/nmap/portasespecificas/historico/nmap443_$DATA.txt
rm -rf /var/www/html/nmap/portasespecificas/data.txt
echo $DATA2 >> /var/www/html/nmap/portasespecificas/data.txt
